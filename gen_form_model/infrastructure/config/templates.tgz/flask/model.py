# -*- coding: UTF-8 -*-

'''
Module
    ${PRO}.py
Copyright
    Copyright (C) ${YEAR}, Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines class ${MODC} with attribute(s) and method(s).
    Web Form ${MODC}.
'''

from __future__ import annotations

from flask_wtf import FlaskForm
from wtforms import (
    BooleanField,
    EmailField,
    StringField,
    SubmitField,
    TextAreaField,
)
from wtforms.validators import (
    DataRequired,
    Email,
    Length,
    Optional,
)

__author__ = 'Vladimir Roncevic'
__copyright__ = '(C) ${YEAR}, Free software to use and distribute it.'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${MODC}(FlaskForm):
    '''
        Defines class ${MODC} with attribute(s) and method(s).
        Web Form ${MODC}.

        It defines:

            :attributes:
                | name - String field for text input.
                | email - Email field for email input.
                | message - Text area field for longer text.
                | is_active - Boolean field for checkbox.
                | submit - Submit button field.
            :methods:
                | None.
    '''

    name = StringField(
        'Name',
        validators=[DataRequired(), Length(min=2, max=100)],
        render_kw={'class': 'form-control', 'placeholder': 'Enter name'}
    )
    email = EmailField(
        'Email',
        validators=[DataRequired(), Email()],
        render_kw={'class': 'form-control', 'placeholder': 'Enter email'}
    )
    message = TextAreaField(
        'Message',
        validators=[Optional(), Length(max=500)],
        render_kw={'class': 'form-control', 'rows': 4, 'placeholder': 'Enter message'}
    )
    is_active = BooleanField(
        'Active',
        default=True
    )
    submit = SubmitField(
        'Submit',
        render_kw={'class': 'btn btn-primary'}
    )
