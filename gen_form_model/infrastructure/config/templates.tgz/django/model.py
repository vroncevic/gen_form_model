# -*- coding: UTF-8 -*-

'''
Module
    ${PRO}.py
Copyright
    Copyright (C) ${YEAR}, Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines class ${MODC} with attribute(s) and method(s).
    Web Form ${MODC}.
'''

from __future__ import annotations

from typing import Any

from django.forms import (
    BooleanField,
    CharField,
    EmailField,
    Form,
)
from django.forms.widgets import (
    EmailInput,
    Textarea,
    TextInput,
)

__author__ = 'Vladimir Roncevic'
__copyright__ = '(C) ${YEAR}, Free software to use and distribute it.'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${MODC}(Form):
    '''
        Defines class ${MODC} with attribute(s) and method(s).
        Web Form ${MODC}.

        It defines:

            :attributes:
                | name - Form field for text input.
                | email - Form field for email input.
                | message - Form field for textarea input.
                | is_active - Form field for boolean confirmation.
            :methods:
                | clean - Validates and cleans form data.
    '''

    name = CharField(
        max_length=100,
        required=True,
        widget=TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter name'})
    )
    email = EmailField(
        required=True,
        widget=EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'})
    )
    message = CharField(
        required=False,
        widget=Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Enter message'})
    )
    is_active = BooleanField(
        required=False,
        initial=True
    )

    def clean(self) -> dict[str, Any]:
        '''
            Validates and cleans form data.

            :return: Cleaned form data dictionary.
            :exceptions: None.
        '''
        return self.cleaned_data

